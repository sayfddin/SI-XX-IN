from flask import Flask, request, jsonify, send_file
import requests
from PIL import Image, ImageDraw, ImageFont
from io import BytesIO
import os

app = Flask(__name__)  
main_key = "S1X-TEAM"

# ✅ جلب بيانات اللاعب
def fetch_player_info(uid):
    url = f'https://masry-info.vercel.app/info?uid={uid}'
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    return None

# ✅ تحميل صورة
def fetch_and_process_image(image_url, size=None):
    try:
        response = requests.get(image_url)
        if response.status_code == 200:
            image = Image.open(BytesIO(response.content)).convert("RGBA")
            if size:
                image = image.resize(size)
            return image
        return None
    except:
        return None

@app.route('/outfit-image', methods=['GET'])
def outfit_image():
    uid = request.args.get('uid')
    key = request.args.get('key')

    if not uid:
        return jsonify({'error': 'Missing uid'}), 400
    if key != main_key:
        return jsonify({'error': 'Invalid or missing API key'}), 403

    data = fetch_player_info(uid)
    if not data:
        return jsonify({'error': 'Failed to fetch player info'}), 500

    # ✅ البيانات المطلوبة
    basic = data.get("basicInfo", {})
    clan = data.get("clanBasicInfo", {})
    head_pic_id = basic.get("headPic")
    nickname = basic.get("nickname", "Unknown")
    level = basic.get("level", 0)
    liked = basic.get("liked", 0)
    clan_name = clan.get("clanName", "No Clan")

    if not head_pic_id:
        return jsonify({'error': 'headPic not found'}), 404

    head_url = f'https://www.dl.cdn.freefireofficial.com/icons/{head_pic_id}.png'

    # ✅ خلفية
    bg_url = 'https://iili.io/Khs3wZv.png'
    background_image = fetch_and_process_image(bg_url, size=(1200, 500))
    if not background_image:
        return jsonify({'error': 'Failed to fetch background image'}), 500

    # ✅ صورة headPic
    head_image = fetch_and_process_image(head_url, size=(210, 210))
    if not head_image:
        return jsonify({'error': 'Failed to fetch headPic image'}), 500

    # ✅ لصقها في النص
    center_x = (495 - head_image.width) // 2
    center_y = (513 - head_image.height) // 2
    background_image.paste(head_image, (center_x, center_y), head_image)

    # ✅ كتابة النصوص
    # ✅ كتابة النصوص
draw = ImageDraw.Draw(background_image)
try:
    # استخدام خط جوجل نوتو
    font = ImageFont.truetype("NotoSansArabic-Regular.ttf", 40)  
except:
    # fallback في حالة الخط مش موجود
    font = ImageFont.truetype("DejaVuSans.ttf", 40)

text_color = (0, 0, 0)  # أسود

draw.text((50, 50), f"👤 Name: {nickname}", font=font, fill=text_color)
draw.text((90, 190), f"{level}", font=font, fill=text_color)
draw.text((50, 170), f"👍 Likes: {liked}", font=font, fill=text_color)
draw.text((50, 230), f"🏆 Clan: {clan_name}", font=font, fill=text_color)

# ✅ إخراج الصورة
img_io = BytesIO()
background_image.save(img_io, 'PNG')
img_io.seek(0)
return send_file(img_io, mimetype='image/png')

# ✅ التشغيل
if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)